package com.gadgetgalore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.gadgetgalore.entity.Admin;
import com.gadgetgalore.service.AdminService;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
@RestController
//@RequestMapping("/api/admins")
public class AdminController
{
	@Autowired
	AdminService aservice;
	
	
	@PostMapping("/Admin/addAdmin")
	public ResponseEntity<Admin> saveAdmin(@Valid @RequestBody Admin admin)
	{
		return new ResponseEntity<Admin>(aservice.addAdmin(admin),HttpStatus.CREATED);
		
	}
	
//	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//    public Admin saveAdmin(@RequestBody Admin admin) {
//        return aservice.addAdmin(admin);
//    }
	
	//@PathVariable : bind to URI template variable
		//http://localhost:8080/Teacher/get(1)
		@GetMapping("/Admin/get/{aid}")
		public ResponseEntity<Admin> getAdmin(@PathVariable ("aid") int aid)
		{
			return new ResponseEntity<Admin>(aservice.getAdminDetail(aid),HttpStatus.OK);
		}
		
		// delete
		@DeleteMapping("/Admin/remove/{aid}")
		public ResponseEntity<String> deleteAdmin(@PathVariable ("aid") int aid)
		{
			aservice.deleteAdminDetail(aid);
			return new ResponseEntity<String>("Deleted Sucessfully", HttpStatus.OK);
		}
		
		//update
		//@RequestBody : Student object call to JSON file
		@PutMapping("/Admin/update/{aid}")
		public ResponseEntity<String> updateAdmin(@RequestBody Admin admin,@PathVariable("aid") int aid) {
		aservice.updateAdminDetail(admin,aid); // Delegate to service layer
		return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
		
		}
}
