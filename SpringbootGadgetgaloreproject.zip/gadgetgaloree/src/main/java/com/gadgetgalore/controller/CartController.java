package com.gadgetgalore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.gadgetgalore.entity.Cart;
import com.gadgetgalore.entity.User;
import com.gadgetgalore.service.CartService;

import jakarta.validation.Valid;

@RestController
public class CartController 
{
	@Autowired
	CartService cservice;
	
	@PostMapping("/Cart/addCart")
	public ResponseEntity<Cart> saveCart(@Valid @RequestBody Cart cart)
	{
		return new ResponseEntity<Cart>(cservice.addCart(cart),HttpStatus.CREATED);
		
	}
	
	//@PathVariable : bind to URI template variable
		//http://localhost:8080/Teacher/get(1)
		@GetMapping("/Cart/get/{cid}")
		public ResponseEntity<Cart> getCart(@PathVariable ("cid") int cid)
		{
			return new ResponseEntity<Cart>(cservice.getCartDetail(cid),HttpStatus.OK);
		}
		
		// delete
		@DeleteMapping("/Cart/remove/{cid}")
		public ResponseEntity<String> deleteCart(@PathVariable ("cid") int cid)
		{
			cservice.deleteCartDetail(cid);
			return new ResponseEntity<String>("Deleted Sucessfully", HttpStatus.OK);
		}
		
		//update
		//@RequestBody : Student object call to JSON file
		@PutMapping("/User/update/{cid}")
		public ResponseEntity<String> updateCart(@RequestBody Cart cart,@PathVariable("cid") int cid) {
		cservice.updateCartDetail(cart,cid); // Delegate to service layer
		return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
		
		}
}
