package com.gadgetgalore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.gadgetgalore.entity.Feedback;
import com.gadgetgalore.service.FeedbackService;

import jakarta.validation.Valid;

@RestController
public class FeedbackController
{
	@Autowired
	FeedbackService fservice;
	
	@PostMapping("/Feedback/addFeedback")
	public  ResponseEntity<Feedback> saveFeedback(@Valid @RequestBody Feedback feedback)
	{
		return new ResponseEntity<Feedback>(fservice.addFeedback(feedback),HttpStatus.CREATED);
		
	}
	
	//@PathVariable : bind to URI template variable
			//http://localhost:8080/Teacher/get(1)
			@GetMapping("/Feedback/get/{fid}")
			public ResponseEntity<Feedback> getFeedback(@PathVariable ("fid") int fid)
			{
				return new ResponseEntity<Feedback>(fservice.getFeedbackDetail(fid),HttpStatus.OK);
			}
			
			// delete
			@DeleteMapping("/Feedback/remove/{fid}")
			public ResponseEntity<String> deleteFeedback(@PathVariable ("fid") int fid)
			{
				fservice.deleteFeedbackDetail(fid);
				return new ResponseEntity<String>("Deleted Sucessfully", HttpStatus.OK);
			}
			
			//update
			//@RequestBody : Student object call to JSON file
			@PutMapping("/Feedback/update/{fid}")
			public ResponseEntity<String> updateFeedback(@RequestBody Feedback feedback,@PathVariable("fid") int fid) {
			fservice.updateFeedbackDetail(feedback,fid); // Delegate to service layer
			return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
			
			}
}
