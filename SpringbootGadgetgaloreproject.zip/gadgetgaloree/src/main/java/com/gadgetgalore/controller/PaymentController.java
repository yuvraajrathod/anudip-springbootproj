package com.gadgetgalore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.gadgetgalore.entity.Payment;
import com.gadgetgalore.service.PaymentService;

import jakarta.validation.Valid;

@RestController
public class PaymentController
{
	@Autowired
	PaymentService payservice;
	
	@PostMapping("/Payment/addPayment")
	public ResponseEntity<Payment> savePayment(@Valid @RequestBody Payment payment)
	{
		return new ResponseEntity<Payment>(payservice.addPayment(payment),HttpStatus.CREATED);
		
	}
	
	//@PathVariable : bind to URI template variable
		//http://localhost:8080/Teacher/get(1)
		@GetMapping("/Payment/get/{payment_id}")
		public ResponseEntity<Payment> getPayment(@PathVariable ("payment_id") int payment_id)
		{
			return new ResponseEntity<Payment>(payservice.getPaymentDetail(payment_id),HttpStatus.OK);
		}
}
