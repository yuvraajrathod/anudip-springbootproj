package com.gadgetgalore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.gadgetgalore.entity.Order;
import com.gadgetgalore.entity.User;
import com.gadgetgalore.service.OrderService;

import jakarta.validation.Valid;

@RestController
public class OrderController
{
	@Autowired
	OrderService oservice;
	
	@PostMapping("/Order_Details/addOrder")
	public ResponseEntity<Order> saveOrder(@Valid @RequestBody Order order)
	{
		return new ResponseEntity<Order>(oservice.addOrder(order),HttpStatus.CREATED);
		
	}
	
	//@PathVariable : bind to URI template variable
		//http://localhost:8080/Teacher/get(1)
		@GetMapping("/Order/get/{oid}")
		public ResponseEntity<Order> getOrder(@PathVariable ("oid") int oid)
		{
			return new ResponseEntity<Order>(oservice.getOrderDetail(oid),HttpStatus.OK);
		}
		
		// delete
		@DeleteMapping("/Order/remove/{oid}")
		public ResponseEntity<String> deleteOrder(@PathVariable ("oid") int oid)
		{
			oservice.deleteOrderDetail(oid);
			return new ResponseEntity<String>("Deleted Sucessfully", HttpStatus.OK);
		}
		
		//update
		//@RequestBody : Student object call to JSON file
		@PutMapping("/Order/update/{oid}")
		public ResponseEntity<String> updateOrder(@RequestBody Order order,@PathVariable("oid") int oid) {
		oservice.updateOrderDetail(order,oid); // Delegate to service layer
		return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
		
		}
}
