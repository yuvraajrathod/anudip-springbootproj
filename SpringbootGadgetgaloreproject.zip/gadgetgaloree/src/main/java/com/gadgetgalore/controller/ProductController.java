package com.gadgetgalore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.gadgetgalore.entity.Product;
import com.gadgetgalore.entity.User;
import com.gadgetgalore.service.ProductService;

import jakarta.validation.Valid;

@RestController
public class ProductController
{
	@Autowired
	ProductService pservice;
	
	@PostMapping("/Product/addProduct")
	public ResponseEntity<Product> saveProduct(@Valid @RequestBody Product product)
	{
		return new ResponseEntity<Product>(pservice.addProduct(product),HttpStatus.CREATED);
		
	}
	
	//@PathVariable : bind to URI template variable
		//http://localhost:8080/Teacher/get(1)
		@GetMapping("/Product/get/{pid}")
		public ResponseEntity<Product> getProduct(@PathVariable ("pid") int pid)
		{
			return new ResponseEntity<Product>(pservice.getProductDetail(pid),HttpStatus.OK);
		}
		
		// delete
		@DeleteMapping("/Product/remove/{pid}")
		public ResponseEntity<String> deleteProduct(@PathVariable ("pid") int pid)
		{
			pservice.deleteProductDetail(pid);
			return new ResponseEntity<String>("Deleted Sucessfully", HttpStatus.OK);
		}
		
		//update
		//@RequestBody : Student object call to JSON file
		@PutMapping("/Product/update/{pid}")
		public ResponseEntity<String> updateProduct(@RequestBody Product product,@PathVariable("pid") int pid) {
		pservice.updateProductDetail(product,pid); // Delegate to service layer
		return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
		
		}
}
