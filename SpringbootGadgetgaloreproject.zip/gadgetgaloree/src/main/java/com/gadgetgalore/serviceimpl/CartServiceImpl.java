package com.gadgetgalore.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gadgetgalore.entity.Cart;
import com.gadgetgalore.entity.User;
import com.gadgetgalore.exception.CartIdNotFoundException;
import com.gadgetgalore.exception.PaymentIdNotFoundException;
import com.gadgetgalore.exception.UserIdNotFoundException;
import com.gadgetgalore.repository.CartRepository;
import com.gadgetgalore.service.CartService;

@Service
public class CartServiceImpl implements CartService
{
	@Autowired
	CartRepository cRepo;

	@Override
	public Cart addCart(Cart cart) {
		return cRepo.save(cart);
	}

	@Override
	public Cart getCartDetail(int cid) {
		return cRepo.findById(cid).
				orElseThrow(()-> new CartIdNotFoundException("Cart id is not corrected"));
	}

	@Override
	public Cart updateCartDetail(Cart cart, int cid) {
		Cart UpdateCart = cRepo.findById(cid).
				orElseThrow(()-> new CartIdNotFoundException("Cart id is not corrected"));
				// set new value
		//Student.setSphone(student.getSphone());
		//UpdateCart.setQuantity(cart.getQuantity());
	
		cRepo.save(UpdateCart);
		return UpdateCart;
	}

	@Override
	public void deleteCartDetail(int cid) {
		Cart delCart =cRepo.findById(cid).
				orElseThrow(()-> new CartIdNotFoundException("Batch id is not corrected"));
		cRepo.delete(delCart);
	}

}
