package com.gadgetgalore.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gadgetgalore.entity.Admin;
import com.gadgetgalore.exception.AdminIdNotFoundException;
import com.gadgetgalore.repository.AdminRepository;
import com.gadgetgalore.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService
{
	@Autowired
	AdminRepository aRepo;
	
	@Override
	public Admin addAdmin(Admin admin) {
		return aRepo.save(admin);
	}

	@Override
	public Admin getAdminDetail(int aid) {
		return aRepo.findById(aid).
				orElseThrow(()-> new AdminIdNotFoundException("Admin id is not corrected"));
	}

	@Override
	public Admin updateAdminDetail(Admin admin, int aid) {
		Admin UpdateAdmin = aRepo.findById(aid).
				orElseThrow(()-> new AdminIdNotFoundException("Admin id is not corrected"));
				// set new value
		//Student.setSphone(student.getSphone());
		//UpdateAdmin.setAphone(admin.getAphone());
		//UpdateAdmin.setAddr(admin.getAddr());
		aRepo.save(UpdateAdmin);
		return UpdateAdmin;
	}

	@Override
	public void deleteAdminDetail(int aid) {
		Admin delAdmin =aRepo.findById(aid).
				orElseThrow(()-> new AdminIdNotFoundException("Admin id is not corrected"));
		aRepo.delete(delAdmin);
		
	}
	
}
