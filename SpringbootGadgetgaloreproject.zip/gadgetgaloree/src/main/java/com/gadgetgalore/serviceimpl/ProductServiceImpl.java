package com.gadgetgalore.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gadgetgalore.entity.Product;
import com.gadgetgalore.entity.User;
import com.gadgetgalore.exception.ProductIdNotFoundException;
import com.gadgetgalore.exception.UserIdNotFoundException;
import com.gadgetgalore.repository.ProductRepository;
import com.gadgetgalore.service.ProductService;


@Service
public class ProductServiceImpl implements ProductService
{
	@Autowired
	ProductRepository pRepo;

	@Override
	public Product addProduct(Product product) {
		return pRepo.save(product);
	}

	@Override
	public Product getProductDetail(int pid) {
		return pRepo.findById(pid).
				orElseThrow(()-> new ProductIdNotFoundException("User id is not corrected"));
	}

	@Override
	public Product updateProductDetail(Product product, int pid) {
		Product UpdateProduct = pRepo.findById(pid).
				orElseThrow(()-> new ProductIdNotFoundException("Batch id is not corrected"));
				// set new value
		//Student.setSphone(student.getSphone());
		//UpdateProduct.setPrice(product.getPrice());
		//UpdateProduct.setQuantity(product.getQuantity());
		pRepo.save(UpdateProduct);
		return UpdateProduct;
	}

	@Override
	public void deleteProductDetail(int pid) {
		Product delProduct =pRepo.findById(pid).
				orElseThrow(()-> new ProductIdNotFoundException("Batch id is not corrected"));
		pRepo.delete(delProduct);
	}
	
	
}
