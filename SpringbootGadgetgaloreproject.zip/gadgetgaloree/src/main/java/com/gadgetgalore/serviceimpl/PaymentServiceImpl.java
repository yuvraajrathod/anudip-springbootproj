package com.gadgetgalore.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gadgetgalore.entity.Payment;
import com.gadgetgalore.exception.OrderIdNotFoundException;
import com.gadgetgalore.exception.PaymentIdNotFoundException;
import com.gadgetgalore.repository.PaymentRepository;
import com.gadgetgalore.service.PaymentService;
@Service
public class PaymentServiceImpl implements PaymentService
{
	@Autowired
	PaymentRepository pRepo;
	@Override
	public Payment addPayment(Payment payment) {
		return pRepo.save(payment);
	}

	@Override
	public Payment getPaymentDetail(int payment_id) {
		return pRepo.findById(payment_id).
				orElseThrow(()-> new PaymentIdNotFoundException("Payment id is not corrected"));
	}

	@Override
	public Payment updatePaymentDetail(Payment payment, int payment_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deletePaymentDetail(int payment_id) {
		// TODO Auto-generated method stub
		
	}

}
