package com.gadgetgalore.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gadgetgalore.entity.Order;
import com.gadgetgalore.exception.OrderIdNotFoundException;
import com.gadgetgalore.repository.OrderRepository;
import com.gadgetgalore.service.OrderService;
@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderRepository oRepo;
	@Override
	public Order addOrder(Order order) {
		return oRepo.save(order);
	}

	@Override
	public Order getOrderDetail(int oid) {
		return oRepo.findById(oid).
				orElseThrow(()-> new OrderIdNotFoundException("Order id is not corrected"));
	}

	@Override
	public Order updateOrderDetail(Order order, int oid) {
		Order UpdateOrder = oRepo.findById(oid).
				orElseThrow(()-> new OrderIdNotFoundException("Order id is not corrected"));
				// set new value
		//Student.setSphone(student.getSphone());
		//UpdateOrder.setQuatity(order.getQuatity());
		oRepo.save(UpdateOrder);
		return UpdateOrder;
	}

	@Override
	public void deleteOrderDetail(int oid) {
		Order delOrder =oRepo.findById(oid).
				orElseThrow(()-> new OrderIdNotFoundException("Order id is not corrected"));
		oRepo.delete(delOrder);
	}

}
