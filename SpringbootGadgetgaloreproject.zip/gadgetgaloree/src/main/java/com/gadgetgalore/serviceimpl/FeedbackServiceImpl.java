package com.gadgetgalore.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gadgetgalore.entity.Admin;
import com.gadgetgalore.entity.Feedback;
import com.gadgetgalore.exception.AdminIdNotFoundException;
import com.gadgetgalore.exception.FeedbackIdNotFoundException;
import com.gadgetgalore.repository.FeedbackRepository;
import com.gadgetgalore.service.FeedbackService;
@Service
public class FeedbackServiceImpl implements FeedbackService
{
	@Autowired
	FeedbackRepository fRepo;

	@Override
	public Feedback addFeedback(Feedback feedback) {
		// TODO Auto-generated method stub
		return fRepo.save(feedback);
	}

	@Override
	public Feedback getFeedbackDetail(int fid) {
		return fRepo.findById(fid).
				orElseThrow(()-> new FeedbackIdNotFoundException("Feedback id is not corrected"));
	}

	@Override
	public Feedback updateFeedbackDetail(Feedback feedback, int fid) {
		Feedback UpdateFeedback = fRepo.findById(fid).
				orElseThrow(()-> new FeedbackIdNotFoundException("Feedback id is not corrected"));
				// set new value
		//Student.setSphone(student.getSphone());
		//UpdateFeedback.setRating(feedback.getRating());
		//UpdateFeedback.setComment(feedback.getComment());
		fRepo.save(UpdateFeedback);
		return UpdateFeedback;
	}

	@Override
	public void deleteFeedbackDetail(int fid) {
		Feedback delFeedback =fRepo.findById(fid).
				orElseThrow(()-> new FeedbackIdNotFoundException("Admin id is not corrected"));
		fRepo.delete(delFeedback);
		
	} 
}
