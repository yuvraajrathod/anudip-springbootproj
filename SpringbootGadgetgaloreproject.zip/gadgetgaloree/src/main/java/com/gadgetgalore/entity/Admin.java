package com.gadgetgalore.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
public class Admin 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int aid;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "User Name cannot be blank")
	private String afname;
	
	@Column(length=25)
	private String llname;
	
	@Column(length=10, nullable = false, unique = true)
	@NotNull(message = "User phone cannot be null")
	private long aphone;
	
	@Column(length=25, nullable = false, unique = true)
	@NotBlank(message = "User Email cannot be blank")
	@Email(message = "Email is incorrect")
	private String aemail;
	
	@Column(length=8)
	private String password;
	
	@Column(length=50, nullable = false)
	@NotBlank(message = "User Address cannot be blank")
	private String addr;

	@OneToMany(mappedBy = "admin", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JsonManagedReference
    private List<Product> product;

}
