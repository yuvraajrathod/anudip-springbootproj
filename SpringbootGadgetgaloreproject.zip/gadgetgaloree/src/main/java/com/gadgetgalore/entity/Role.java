package com.gadgetgalore.entity;

public class Role {

}
