package com.gadgetgalore.exception;

public class FeedbackIdNotFoundException extends RuntimeException
{
	public FeedbackIdNotFoundException(String message)
	{
		super(message);
		
	}
}
