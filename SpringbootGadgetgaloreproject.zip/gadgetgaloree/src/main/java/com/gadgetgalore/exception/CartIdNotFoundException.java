package com.gadgetgalore.exception;

public class CartIdNotFoundException extends RuntimeException
{
	public CartIdNotFoundException(String message)
	{
		super(message);
		
	}
}
