package com.gadgetgalore.service;

import com.gadgetgalore.entity.Product;
import com.gadgetgalore.entity.User;

public interface ProductService
{
	// save Student details in db table
				Product addProduct(Product product);
				
				// method to fetch Student detail based on sid from db table
				Product getProductDetail(int pid);
				
				//method to modify Student detail based on sid from db table
				Product updateProductDetail(Product product, int pid);
				
				//method to remove Student detail based on sid from db table
				void deleteProductDetail(int pid);
}
