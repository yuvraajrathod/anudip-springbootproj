package com.gadgetgalore.service;

import com.gadgetgalore.entity.Admin;
import com.gadgetgalore.entity.User;

public interface AdminService 
{
	// save Student details in db table
				Admin addAdmin(Admin admin);
				
				// method to fetch Student detail based on sid from db table
				Admin getAdminDetail(int aid);
				
				//method to modify Student detail based on sid from db table
				Admin updateAdminDetail(Admin admin, int aid);
				
				//method to remove Student detail based on sid from db table
				void deleteAdminDetail(int aid);
}
