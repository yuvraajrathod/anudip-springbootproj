package com.gadgetgalore.service;

import com.gadgetgalore.entity.Admin;
import com.gadgetgalore.entity.Feedback;

public interface FeedbackService 
{
	Feedback addFeedback(Feedback feedback);
	
	// method to fetch Student detail based on sid from db table
	Feedback getFeedbackDetail(int fid);
	
	//method to modify Student detail based on sid from db table
	Feedback updateFeedbackDetail(Feedback feedback, int fid);
	
	//method to remove Student detail based on sid from db table
	void deleteFeedbackDetail(int fid);
}
