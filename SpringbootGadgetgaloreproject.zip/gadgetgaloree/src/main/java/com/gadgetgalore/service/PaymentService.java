package com.gadgetgalore.service;

import com.gadgetgalore.entity.Payment;

public interface PaymentService 
{
	Payment addPayment(Payment payment);
	
	// method to fetch Student detail based on sid from db table
	Payment getPaymentDetail(int payment_id);
	
	//method to modify Student detail based on sid from db table
	Payment updatePaymentDetail(Payment payment, int payment_id);
	
	//method to remove Student detail based on sid from db table
	void deletePaymentDetail(int payment_id);
}
