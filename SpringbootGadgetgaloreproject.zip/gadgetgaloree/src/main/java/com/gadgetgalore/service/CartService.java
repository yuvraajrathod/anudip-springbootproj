package com.gadgetgalore.service;

import com.gadgetgalore.entity.Cart;
import com.gadgetgalore.entity.Product;

public interface CartService 
{
	Cart addCart(Cart cart);
	
	// method to fetch Student detail based on sid from db table
	Cart getCartDetail(int cid);
	
	//method to modify Student detail based on sid from db table
	Cart updateCartDetail(Cart cart, int cid);
	
	//method to remove Student detail based on sid from db table
	void deleteCartDetail(int cid);
}
