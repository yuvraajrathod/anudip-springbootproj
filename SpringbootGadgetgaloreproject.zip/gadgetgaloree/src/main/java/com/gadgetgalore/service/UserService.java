package com.gadgetgalore.service;

import com.gadgetgalore.entity.User;

public interface UserService
{
	// save Student details in db table
			User addUser(User user);
			
			// method to fetch Student detail based on sid from db table
			User getUserDetail(int uid);
			
			//method to modify Student detail based on sid from db table
			User updateUserDetail(User user, int uid);
			
			//method to remove Student detail based on sid from db table
			void deleteUserDetail(int uid);
}
