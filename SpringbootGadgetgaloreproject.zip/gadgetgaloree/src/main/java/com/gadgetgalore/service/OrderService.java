package com.gadgetgalore.service;

import com.gadgetgalore.entity.Order;
import com.gadgetgalore.entity.Product;

public interface OrderService 
{
	Order addOrder(Order order);
	
	// method to fetch Student detail based on sid from db table
	Order getOrderDetail(int oid);
	
	//method to modify Student detail based on sid from db table
	Order updateOrderDetail(Order order, int oid);
	
	//method to remove Student detail based on sid from db table
	void deleteOrderDetail(int oid);
}
