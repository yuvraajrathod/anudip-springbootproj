package com.gadgetgalore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gadgetgalore.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer>
{

}
