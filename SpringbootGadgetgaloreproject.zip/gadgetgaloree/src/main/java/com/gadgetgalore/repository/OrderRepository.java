package com.gadgetgalore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gadgetgalore.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Integer>
{

}
