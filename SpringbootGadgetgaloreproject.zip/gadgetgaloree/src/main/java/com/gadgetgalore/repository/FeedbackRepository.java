package com.gadgetgalore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gadgetgalore.entity.Feedback;

public interface FeedbackRepository extends JpaRepository<Feedback, Integer> {

}
