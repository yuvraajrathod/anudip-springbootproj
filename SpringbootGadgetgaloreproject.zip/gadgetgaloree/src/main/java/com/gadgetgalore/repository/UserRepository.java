package com.gadgetgalore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gadgetgalore.entity.User;

public interface UserRepository extends JpaRepository<User, Integer>
{

}
