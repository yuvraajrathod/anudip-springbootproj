package com.gadgetgalore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gadgetgalore.entity.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer>
{

}
